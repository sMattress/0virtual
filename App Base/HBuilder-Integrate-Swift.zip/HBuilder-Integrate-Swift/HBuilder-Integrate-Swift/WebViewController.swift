//
//  WebViewController.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 17/5/18.
//  Copyright © 2017年 EICAPITAN. All rights reserved.
//

import Foundation

class WebViewController: UIViewController,PDRCoreDelegate {
    
    var webFrame: PDRCoreAppFrame?
    
    override func loadView() {
        super.loadView();
        self.view.backgroundColor = UIColor.orange;
    }
    
    override func viewDidLoad() {
        let pCoreHandle : PDRCore? = PDRCore.instance();
        if(pCoreHandle != nil)
        {
            let pFilePath:String? = String.localizedStringWithFormat("file://%@/%@", Bundle.main.bundlePath, "Pandora/apps/HelloH5/www/plugin.html" );
            
            pCoreHandle?.start();
            pCoreHandle?.coreDeleagete = self;
            pCoreHandle?.persentViewController = self;
            
            let stRect:CGRect? = self.view.bounds;
            
            webFrame = PDRCoreAppFrame.init(name: "WebViewId", loadURL: pFilePath! as String!, frame: stRect!);
            
            pCoreHandle?.appManager.activeApp.appWindow.registerFrame(webFrame);
            self.view.addSubview(webFrame!);
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
