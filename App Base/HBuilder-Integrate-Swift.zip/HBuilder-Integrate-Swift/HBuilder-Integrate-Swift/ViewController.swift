//
//  ViewController.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 17/5/17.
//  Copyright © 2017年 EICAPITAN. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    
    var WebAppButton : UIButton?
    var WebViewButton: UIButton?
    var buttonWidth : CGFloat? = 300
    var buttonHeight : CGFloat? = 50
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var ButtonYPos : CGFloat = 100;
        let ButtonYMargin : CGFloat = 50;
        
        let ButtonXpos:CGFloat = (self.view.frame.size.width - buttonWidth!)/2;
        WebViewButton = UIButton.init(type: UIButtonType.custom);
        WebViewButton?.frame = CGRect(x:ButtonXpos, y: ButtonYPos , width: buttonWidth!, height: buttonHeight!);
        WebViewButton?.setTitle("WebView集成方式", for: UIControlState.normal);
        WebViewButton?.setTitleColor(UIColor.black, for: UIControlState.normal);
        WebViewButton?.addTarget(self, action:#selector(onButtonClick(_:)), for: UIControlEvents.touchUpInside);
        WebViewButton?.tag = 1;
        
        
        ButtonYPos += buttonHeight!;
        ButtonYPos += ButtonYMargin;
        
        WebAppButton = UIButton.init(type: UIButtonType.custom);
        WebAppButton?.frame = CGRect(x:ButtonXpos , y:ButtonYPos, width: buttonWidth!, height: buttonHeight!);
        WebAppButton?.setTitleColor(UIColor.black, for: UIControlState.normal);
        WebAppButton?.setTitle("WebApp集成方式", for: UIControlState.normal);
        WebAppButton?.addTarget(self, action: #selector(onButtonClick(_:)), for: UIControlEvents.touchUpInside);
        WebAppButton?.tag = 2;
        
        
        
        self.view.addSubview(WebViewButton!);
        self.view.addSubview(WebAppButton!);
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(testFunction), name: NSNotification.Name(rawValue: "SendDataToNative"), object: nil);
    }
    
    func testFunction()
    {
        
    }

    
    func onButtonClick(_ button: UIButton) -> () {

        if(button.tag == 1)
        {
            let webViewPage:WebViewController? = WebViewController();
            self.navigationController?.pushViewController(webViewPage!, animated: true);
        }
        else if(button.tag == 2)
        {
            let webAppPage:WebAppController? = WebAppController();
            self.navigationController?.isNavigationBarHidden = true;
            self.navigationController?.pushViewController(webAppPage!, animated: true);            
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

