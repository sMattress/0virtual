//
//  WebAppController.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 17/5/18.
//  Copyright © 2017年 EICAPITAN. All rights reserved.
//

import Foundation

var g_instanceContentView:UIView?

class WebAppController: UIViewController,PDRCoreDelegate {
    
    let pCoreHandle:PDRCore? = PDRCore.instance();
    var pAppHandle:PDRCoreApp?
    
    
    override func viewDidLoad() {
        if(g_instanceContentView == nil)
        {
            g_instanceContentView = UIView.init(frame:self.view.bounds);
        }
        self.view.addSubview(g_instanceContentView!);
        
        pCoreHandle?.coreDeleagete = self;
        pCoreHandle?.persentViewController = self;
        pCoreHandle?.setContainerView(g_instanceContentView!);        
        
        let pWWWPath = Bundle.main.bundlePath + "/Pandora/apps/HelloH5/www";
        let argus = "runtime argument";
        pAppHandle = pCoreHandle?.appManager.openApp(atLocation: pWWWPath, withIndexPath: "index.html", withArgs: argus, with: nil);
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
